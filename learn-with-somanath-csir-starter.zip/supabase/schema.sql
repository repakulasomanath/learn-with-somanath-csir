-- Apply in Supabase SQL Editor. Review RLS policies before production launch.
create extension if not exists pgcrypto;
create type public.question_origin as enum ('official_pyq','ai_generated','adapted_practice','expert_authored');
create type public.review_status as enum ('draft','pending_review','verified','disputed','rejected');
create table public.subjects (
 id uuid primary key default gen_random_uuid(), name text not null unique,
 syllabus_version text, syllabus_reference text, created_at timestamptz default now()
);
create table public.topics (
 id uuid primary key default gen_random_uuid(), subject_id uuid not null references public.subjects(id) on delete cascade,
 name text not null, syllabus_unit text, unique(subject_id,name)
);
create table public.questions (
 id uuid primary key default gen_random_uuid(), topic_id uuid not null references public.topics(id),
 origin public.question_origin not null, exam_name text, exam_session text, exam_year int,
 part text check (part in ('A','B','C')), question_type text not null,
 stem text not null, options jsonb not null, correct_answer jsonb,
 explanation text, difficulty text, source_title text, source_url text, source_page text,
 verification_status public.review_status not null default 'draft',
 reviewer_notes text, created_at timestamptz default now(),
 check ((origin <> 'official_pyq') or (exam_name is not null and exam_year is not null and source_url is not null))
);
create table public.question_sources (
 id uuid primary key default gen_random_uuid(), question_id uuid not null references public.questions(id) on delete cascade,
 citation text not null, source_url text, doi text, pmid text, page_or_section text
);
create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade, display_name text,
 target_exam text default 'CSIR-NET Life Sciences', created_at timestamptz default now()
);
create table public.attempts (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 question_id uuid not null references public.questions(id), selected_answer jsonb,
 is_correct boolean not null, time_spent_seconds int, attempted_at timestamptz default now()
);
create table public.bookmarks (
 user_id uuid not null references auth.users(id) on delete cascade,
 question_id uuid not null references public.questions(id) on delete cascade,
 created_at timestamptz default now(), primary key(user_id,question_id)
);
create table public.research_papers (
 id uuid primary key default gen_random_uuid(), provider text not null, provider_id text,
 title text not null, authors jsonb, journal text, publication_year int, doi text, pmid text,
 pmcid text, abstract text, source_url text not null, retrieved_at timestamptz default now(),
 unique(provider,provider_id)
);
-- RLS: students can see verified questions; writes to question content are admin-only.
alter table public.subjects enable row level security;
alter table public.topics enable row level security;
alter table public.questions enable row level security;
alter table public.question_sources enable row level security;
alter table public.profiles enable row level security;
alter table public.attempts enable row level security;
alter table public.bookmarks enable row level security;
alter table public.research_papers enable row level security;
create policy "Public read subjects" on public.subjects for select using (true);
create policy "Public read topics" on public.topics for select using (true);
create policy "Students read verified questions" on public.questions for select using (verification_status='verified');
create policy "Read sources for verified questions" on public.question_sources for select using (
 exists(select 1 from public.questions q where q.id=question_id and q.verification_status='verified')
);
create policy "Read own profile" on public.profiles for select using (auth.uid()=id);
create policy "Update own profile" on public.profiles for update using (auth.uid()=id);
create policy "Read own attempts" on public.attempts for select using (auth.uid()=user_id);
create policy "Insert own attempts" on public.attempts for insert with check (auth.uid()=user_id);
create policy "Manage own bookmarks" on public.bookmarks for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "Public read research papers" on public.research_papers for select using (true);
-- Production TODO: add an admin role table and policies for trusted reviewers.
-- Do not grant anonymous users write access to questions or verification fields.
