# Learn With Somanath — CSIR Life Science AI Learning Platform

A mobile-first React + TypeScript starter for a CSIR Life Sciences learning platform.

## Included in this MVP starter
- Dashboard and 16 subject modules
- Searchable subject/topic catalogue
- Interactive demo quiz with answer feedback
- Research discovery links (PubMed, NCBI, Europe PMC, Google Scholar)
- AI tutor integration placeholder
- Light/dark theme
- Supabase PostgreSQL schema with question provenance, review states, attempts and bookmarks

## Run locally
1. Install Node.js 20+.
2. Run `npm install`.
3. Run `npm run dev`.
4. Open the local URL printed by Vite.

## Supabase setup
1. Create a Supabase project.
2. Run `supabase/schema.sql` in the SQL Editor.
3. Copy `.env.example` to `.env.local`.
4. Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
5. Add authentication flows and test all RLS policies before using real student data.

The browser anon key is designed to be public; database security must come from correct Row Level Security policies. Never put a service-role key or AI-provider secret in frontend variables.

## Important current limitations
This is a functional frontend prototype, not a deployed production service:
- Quiz uses five clearly labelled demo questions and local session state.
- Login, saved progress, admin moderation and live database reads are not yet wired to the UI.
- Research links open provider websites; live metadata retrieval is not connected.
- AI tutor is a placeholder; connect it through a server-side function.
- Syllabus mapping and official PYQ ingestion require source-by-source review.
- Current CSIR-NET exam structure and marking must be updated from the latest official NTA notification before full mock tests are published.

## Recommended next build steps
1. Add Supabase Auth and profile onboarding.
2. Seed the subjects and syllabus topic mapping using the applicable official syllabus version.
3. Build admin review screens; only approved questions should become `verified`.
4. Add quiz sessions, server-side scoring rules, attempt persistence and analytics.
5. Add PubMed / Europe PMC API integrations with provider IDs and retrieval timestamps.
6. Add a server-side AI endpoint with retrieval only from approved content, citations, uncertainty flags and expert feedback.
7. Add automated tests for question keys, scoring, access control and source metadata.

## Content governance
Never label generated questions as official PYQs. Store exam, year, session, paper source and page/question number for each official item. Preserve official answer-key corrections and flag disputed questions. Obtain appropriate permissions and respect source licensing before bulk importing question papers.
